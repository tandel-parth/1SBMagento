<?php

class Ccc_Jethalal_Model_Observer
{
    public function jalebiJethalal(Varien_Event_Observer $observer)
    {
        // $data = Mage::getModel('ccc_jethalal/jalebi')->getCollection()->getData();
        // echo "<pre>";
        // print_r($data);
    }
    public function setJalebi(){
        echo 123;
    }
}

<?php
class Ccc_Jethalal_Model_Resource_Jalebi extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        $this->_init('ccc_jethalal/jalebi', 'jalebi_id');
    }

}

?>
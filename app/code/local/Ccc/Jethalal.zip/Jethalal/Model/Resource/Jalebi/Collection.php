<?php
class Ccc_Jethalal_Model_Resource_Jalebi_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    protected function _construct()
    {
        $this->_init('ccc_jethalal/jalebi');
    }
}

?>
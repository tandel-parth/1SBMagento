<?php
class Ccc_Productseller_Helper_Data extends Mage_Core_Helper_Abstract
{
   
}

?>
<?php
class Ccc_Productseller_Model_Productseller extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('Ccc_Productseller/productseller');
    }

}

?>
